import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(home: HomeScreen());
  }
}

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String mensaje = "";

  Future<void> loginAnonimo() async {
    await FirebaseAuth.instance.signInAnonymously();
  }

  Future<void> obtenerSaludo() async {
    if (FirebaseAuth.instance.currentUser != null) {
      final respuesta = await http.get(Uri.parse('http://localhost:3000/saludo'));
      if (respuesta.statusCode == 200) {
        setState(() {
          mensaje = json.decode(respuesta.body)['mensaje'];
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('App Flutter + Firebase')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(onPressed: loginAnonimo, child: Text('Login Anónimo')),
            ElevatedButton(onPressed: obtenerSaludo, child: Text('Obtener Saludo')),
            SizedBox(height: 20),
            Text(mensaje),
          ],
        ),
      ),
    );
  }
}
